# CorpSite

## Version 2.x

This is a demo of a corporate website.  The goal is to show changes to this app propigate through the ServiceNow DevOps app.
